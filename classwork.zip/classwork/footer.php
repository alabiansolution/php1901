<footer>
	<p>
		&copy; Copyright  Alabian Solutions
	</p>
</footer>
