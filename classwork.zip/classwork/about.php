<?php require_once "head.php" ?>
<body>
	<?php require_once "menu.php" ?>
	<h1>Home Page</h1>
	<?php require_once "footer.php" ?>
	
</body>
</html>