<a href="#">Home</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="#">About</a>&nbsp;&nbsp;&nbsp;&nbsp;
<a href="contact.php">Contact</a>